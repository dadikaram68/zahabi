import { describe, expect, it } from "vitest";
import { getHomeSectionAccess } from "../shared/homeAccess";

describe("home section access", () => {
  it("shows only explicitly delegated inventory sections to a role-assigned warehouse user", () => {
    const access = getHomeSectionAccess({
      isOwner: false,
      roles: ["custom_warehouse"],
      permissions: ["inventory.read"],
      hasAccessRecord: true,
      canAccessAccounting: false,
    });
    expect(access.sections).toEqual([
      "dashboard",
      "items",
      "movements",
      "reports",
    ]);
    expect(access.inventoryManage).toBe(false);
    expect(access.commerce).toBe(false);
    expect(access.backups).toBe(false);
  });
  it("keeps owner access and blocks a direct backup section for a delegated inventory-only user", () => {
    const owner = getHomeSectionAccess({
      isOwner: true,
      roles: ["system_admin"],
      permissions: ["*"],
      hasAccessRecord: true,
      canAccessAccounting: true,
    });
    expect(owner.sections).toContain("backups");
    const staff = getHomeSectionAccess({
      isOwner: false,
      roles: ["custom_warehouse"],
      permissions: ["inventory.manage"],
      hasAccessRecord: true,
      canAccessAccounting: false,
    });
    expect(staff.sections).not.toContain("backups");
    expect(staff.inventoryManage).toBe(true);
  });
  it("respects explicit menu permissions for dashboard visibility", () => {
    const access = getHomeSectionAccess({
      isOwner: false,
      roles: ["custom_manager"],
      permissions: ["menu.items", "inventory.manage"],
      hasAccessRecord: true,
      canAccessAccounting: false,
    });
    expect(access.sections).not.toContain("dashboard");
    expect(access.sections).toContain("items");
  });
});
