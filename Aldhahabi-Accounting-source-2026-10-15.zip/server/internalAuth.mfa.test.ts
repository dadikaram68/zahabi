import { describe, expect, it } from "vitest";
import { generateTotpCode, generateTotpSecret, verifyTotpCode } from "./internalAuth";

describe("internal MFA TOTP", () => {
  it("generates a six-digit code accepted within the clock-skew window", () => {
    const secret = generateTotpSecret();
    const now = 1_735_689_600_000;
    const code = generateTotpCode(secret, now);
    expect(code).toMatch(/^\d{6}$/);
    expect(verifyTotpCode(secret, code, now)).toBe(true);
    expect(verifyTotpCode(secret, code, now + 120_000)).toBe(false);
  });

  it("rejects a malformed or incorrect code", () => {
    const secret = generateTotpSecret();
    expect(verifyTotpCode(secret, "000000", 1_735_689_600_000)).toBe(false);
    expect(() => generateTotpCode("not-a-secret", Date.now())).toThrow();
  });
});
