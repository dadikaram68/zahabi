import { describe, expect, it } from "vitest";
import { hashInternalPassword, normalizeUsername, verifyInternalPassword } from "./internalAuth";

describe("internal user authentication", () => {
  it("normalizes usernames and verifies only the matching password against an scrypt hash", async () => {
    const hash = await hashInternalPassword("A-strong-password-2026");
    expect(hash.startsWith("scrypt$")).toBe(true);
    await expect(verifyInternalPassword("A-strong-password-2026", hash)).resolves.toBe(true);
    await expect(verifyInternalPassword("different-password", hash)).resolves.toBe(false);
    expect(normalizeUsername("  Accountant.01  ")).toBe("accountant.01");
  });
});
