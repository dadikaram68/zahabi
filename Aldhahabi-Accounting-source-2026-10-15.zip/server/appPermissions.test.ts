import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getAccountingPermissions: vi.fn(),
  getAccountingRoleCodes: vi.fn(),
}));
vi.mock("./accountingDb", () => mocks);

import { hasDelegatedAppPermission } from "./appPermissions";

describe("delegated app permissions", () => {
  beforeEach(() => {
    mocks.getAccountingPermissions.mockReset();
    mocks.getAccountingRoleCodes.mockReset();
  });
  it("permits the owner and existing unassigned users without breaking historical access", async () => {
    await expect(
      hasDelegatedAppPermission({
        userId: 1,
        globalRole: "admin",
        permission: "inventory.manage",
      })
    ).resolves.toBe(true);
    mocks.getAccountingPermissions.mockResolvedValue([]);
    mocks.getAccountingRoleCodes.mockResolvedValue([]);
    await expect(
      hasDelegatedAppPermission({
        userId: 2,
        globalRole: "user",
        permission: "inventory.manage",
      })
    ).resolves.toBe(true);
  });
  it("enforces a delegated section permission when the user has a role assignment", async () => {
    mocks.getAccountingRoleCodes.mockResolvedValue(["custom_sales"]);
    mocks.getAccountingPermissions.mockResolvedValue(["commerce.manage"]);
    await expect(
      hasDelegatedAppPermission({
        userId: 3,
        globalRole: "user",
        permission: "commerce.manage",
      })
    ).resolves.toBe(true);
    await expect(
      hasDelegatedAppPermission({
        userId: 3,
        globalRole: "user",
        permission: "inventory.manage",
      })
    ).resolves.toBe(false);
  });
  it("inherits read access from the matching management permission", async () => {
    mocks.getAccountingRoleCodes.mockResolvedValue(["custom_manager"]);
    mocks.getAccountingPermissions.mockResolvedValue([
      "inventory.manage",
      "accounting.manage",
      "commerce.manage",
    ]);
    await expect(
      hasDelegatedAppPermission({
        userId: 4,
        globalRole: "user",
        permission: "inventory.read",
      })
    ).resolves.toBe(true);
    await expect(
      hasDelegatedAppPermission({
        userId: 4,
        globalRole: "user",
        permission: "accounting.read",
      })
    ).resolves.toBe(true);
    await expect(
      hasDelegatedAppPermission({
        userId: 4,
        globalRole: "user",
        permission: "commerce.read",
      })
    ).resolves.toBe(true);
  });
});
